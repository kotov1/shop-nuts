<footer>
		<div class="footer__top-line">
		<div class="container">
			<div class="row">

				<div class="col-12 col-md-3 col-lg-4">
					<div class="logo">
						<img src="img/ru.png" alt="logo" class="img-responsive">
						<p class="site-description">орехи со всего мира</p>
						<div class="social-icon">
							<span style="background: url(img/social_vk.png);"></span>
							<span style="background: url(img/social_gPlus.png);"></span>
						</div>
					</div>
				</div>

				<div class="col-12 col-md-5 col-lg-5">
					<div class="search">
						<form action="" class="search-form">
							<input type="search" placeholder="Поиск товара">
						</form>
					</div>
				</div>

				<div class="col-12 col-md-4 col-lg-3">
					<div class= "offer">
						<p class="tel"><span>8(812)</span> 309-95-91</p>
						<a href="#" class="a">заказать звонок</a>
					</div>
				</div>
			</div>
		</div>
	</div>

	<div class="footer__bottom">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<p class="politic">2017 © Все права защищены <a href="">Политика конфиденциальности</a></p>
				</div>
			</div>
		</div>
	</div>
</footer>